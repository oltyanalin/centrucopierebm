<?php
session_start();

// Verifică dacă utilizatorul este autentificat ca administrator
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    // Redirecționează la pagina de autentificare
    header('Location: /centrucopierebm.ro/admin/login.php');
    exit;
}
?>
