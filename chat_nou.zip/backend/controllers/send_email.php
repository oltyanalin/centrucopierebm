<?php

// Include fișierele necesare PHPMailer
require '/home/planuri1/public_html/PHPMailer/src/Exception.php';
require '/home/planuri1/public_html/PHPMailer/src/PHPMailer.php';
require '/home/planuri1/public_html/PHPMailer/src/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Funcție pentru trimiterea emailurilor
function sendEmail($to, $subject, $body, $altBody = '')
{
    // Încarcă configurația SMTP
    $smtpConfig = include '/home/planuri1/public_html/centrucopierebm.ro/backend/config/smtp_config.php';

    // Inițializează PHPMailer
    $mail = new PHPMailer(true);

    try {
        // Setările serverului
        $mail->isSMTP();
        $mail->Host = $smtpConfig['host'];
        $mail->SMTPAuth = true;
        $mail->Username = $smtpConfig['username'];
        $mail->Password = $smtpConfig['password'];
        $mail->SMTPSecure = $smtpConfig['encryption'];
        $mail->Port = $smtpConfig['port'];

        // Setări pentru expeditor
        $mail->setFrom($smtpConfig['from_email'], $smtpConfig['from_name']);

        // Setări pentru destinatar
        $mail->addAddress($to);

        // Conținutul emailului
        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body    = $body;
        $mail->AltBody = $altBody; // Text simplu alternativ

        // Trimite emailul
        $mail->send();
        echo 'Emailul a fost trimis cu succes!';
    } catch (Exception $e) {
        echo "Emailul nu a putut fi trimis. Eroare: {$mail->ErrorInfo}";
    }
}

?>
