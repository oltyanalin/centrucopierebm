<?php
session_start();

// Include configurarea bazei de date
include '../config/db.php';

// Include configurarea pentru FTP
include '../config/ftp.php';

// Verifică dacă formularul a fost trimis
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $customer_name = $_POST['customerName'];
    $customer_phone = $_POST['customerPhone'];
    $customer_email = isset($_POST['customerEmail']) ? $_POST['customerEmail'] : ''; // email opțional
    $format = $_POST['format'];
    $order_details = isset($_POST['orderDetails']) ? $_POST['orderDetails'] : '';

    // Verifică dacă fișierele sunt detectate
    if (empty($_FILES['files']['name'][0])) {
        echo json_encode(['status' => 'error', 'message' => 'Te rugăm să încarci cel puțin un fișier.']);
        exit();
    }

    try {
        // Conectează-te la baza de date
        $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $user, $pass);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Găsește ultimul ID de comandă și calculează următorul
        $stmt = $pdo->query("SELECT MAX(id) as max_id FROM orders");
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $order_id = str_pad($row['max_id'] + 1, 5, '0', STR_PAD_LEFT);

        // Creează comanda în baza de date
        $stmt = $pdo->prepare("INSERT INTO orders (order_id, customer_name, customer_phone, customer_email, format, details) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->execute([$order_id, $customer_name, $customer_phone, $customer_email, $format, $order_details]);

    } catch (PDOException $e) {
        echo json_encode(['status' => 'error', 'message' => "Database error: " . $e->getMessage()]);
        exit();
    }

    // Verifică și încarcă fișierele
    $upload_dir = '../../uploads/'; // Directorul local unde sunt stocate temporar fișierele
    $file_paths = [];

    // Creează directorul pentru comanda curentă local
    $local_order_directory = $upload_dir . "$order_id-$customer_name/";
    if (!is_dir($local_order_directory)) {
        if (!mkdir($local_order_directory, 0777, true)) {
            echo json_encode(['status' => 'error', 'message' => 'Eroare la crearea directorului local.']);
            exit();
        }
    }

    foreach ($_FILES['files']['name'] as $key => $name) {
        $tmp_name = $_FILES['files']['tmp_name'][$key];
        $file_name = basename($name);
        $target_file = $local_order_directory . $file_name; // Salvează fișierul cu numele original

        // Mută fișierul în directorul de uploads local
        if (move_uploaded_file($tmp_name, $target_file)) {
            $file_paths[] = $target_file;

            // Creează structura directorului pe NAS
            $nas_directory = "$order_id-$customer_name/";

            // Utilizează funcția din ftp.php pentru a încărca fișierul pe NAS
            $upload_result = uploadFileToNas($target_file, $nas_directory, $file_name);

            if ($upload_result['status'] !== 'success') {
                echo json_encode(['status' => 'error', 'message' => $upload_result['message']]);
                exit();
            }

            // Opțional: Șterge fișierul local după încărcare cu succes pe NAS
            unlink($target_file);

        } else {
            echo json_encode(['status' => 'error', 'message' => "Eroare la încărcarea fișierului $file_name."]);
            exit();
        }
    }

    // Convert file paths to JSON for storage
    $file_paths_json = json_encode($file_paths);

    // Actualizează calea fișierelor în baza de date
    $stmt = $pdo->prepare("UPDATE orders SET file_paths = ? WHERE order_id = ?");
    $stmt->execute([$file_paths_json, $order_id]);

    // Creează fișierul de detalii al comenzii
    $order_details_content = "Nume client: $customer_name\nTelefon: $customer_phone\nEmail: $customer_email\nFormat: $format\nDetalii: $order_details\nNumăr fișiere: " . count($file_paths);

    // Calea către fișierul de detalii
    $order_details_path = $local_order_directory . "order_details_$order_id.txt";

    // Salvează detaliile comenzii într-un fișier text
    file_put_contents($order_details_path, $order_details_content);

    // Încarcă fișierul de detalii pe NAS
    $upload_result = uploadFileToNas($order_details_path, $nas_directory, "order_details.txt");

    if ($upload_result['status'] !== 'success') {
        echo json_encode(['status' => 'error', 'message' => $upload_result['message']]);
        exit();
    }

    // Șterge fișierul local al detaliilor
    unlink($order_details_path);

    // Șterge directorul local după ce fișierele sunt mutate pe NAS
    rmdir($local_order_directory);

    echo json_encode(['status' => 'success', 'message' => 'Comanda a fost înregistrată cu succes!']);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Cerere invalidă.']);
}
?>