<?php
return [
    'host' => 'smtp.zoho.com',
    'port' => 465,
    'username' => 'office@centrucopierebm.ro', // Adresa ta de email
    'password' => 'Printare123',               // Parola ta de email
    'encryption' => 'ssl',                     // Folosim SSL conform setărilor Zoho
    'from_email' => 'office@centrucopierebm.ro', // Adresa de email a expeditorului
    'from_name' => 'Centru Copiere BM'         // Numele care apare ca expeditor
];
?>
