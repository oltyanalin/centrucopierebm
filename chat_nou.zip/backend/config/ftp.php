<?php
// Funcție pentru a încărca un fișier pe NAS folosind FTP
function uploadFileToNas($localFilePath, $remoteDirectory, $remoteFileName) {
    $ftpHost = '5.13.247.227'; // Adresa IP a NAS-ului
    $ftpUsername = 'centru';   // Numele de utilizator FTP
    $ftpPassword = 'Ropressodigit@l123!'; // Parola FTP

    // Conectare la serverul FTP
    $ftpConnection = ftp_connect($ftpHost);
    if (!$ftpConnection) {
        return ['status' => 'error', 'message' => 'Nu s-a putut conecta la serverul FTP.'];
    }

    // Autentificare pe serverul FTP
    $loginResult = ftp_login($ftpConnection, $ftpUsername, $ftpPassword);
    if (!$loginResult) {
        ftp_close($ftpConnection);
        return ['status' => 'error', 'message' => 'Autentificare FTP eșuată.'];
    }

    // Asigură-te că conexiunea FTP este pasivă (necesar pentru unele servere)
    ftp_pasv($ftpConnection, true);

    // Verifică dacă directorul țintă există și creează-l dacă nu există
    if (!ftp_chdir($ftpConnection, $remoteDirectory)) {
        if (!ftp_mkdir($ftpConnection, $remoteDirectory)) {
            ftp_close($ftpConnection);
            return ['status' => 'error', 'message' => "Nu s-a putut crea directorul pe NAS: $remoteDirectory"];
        }
        // Revin-o la directorul rădăcină pentru a naviga către noul director creat
        ftp_chdir($ftpConnection, $remoteDirectory);
    }

    // Încarcă fișierul pe NAS
    $upload = ftp_put($ftpConnection, $remoteFileName, $localFilePath, FTP_BINARY);
    if (!$upload) {
        ftp_close($ftpConnection);
        return ['status' => 'error', 'message' => "Eroare la încărcarea fișierului $remoteFileName pe NAS."];
    }

    // Închide conexiunea FTP
    ftp_close($ftpConnection);

    return ['status' => 'success', 'message' => "Fișierul $remoteFileName a fost încărcat cu succes pe NAS."];
}
?>
