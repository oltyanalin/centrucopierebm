document.addEventListener("DOMContentLoaded", function () {
    // Calculul dinamic al prețului pentru pagina de printare foto
    const photoOrderForm = document.getElementById('photoOrderForm');
    if (photoOrderForm) {
        const formatSelect = document.getElementById('format');
        const quantityInput = document.getElementById('quantity');
        const priceDisplay = document.createElement('div');
        priceDisplay.className = "price-display mt-4 text-lg font-bold text-primary-color";
        photoOrderForm.appendChild(priceDisplay);

        const formatPrices = {
            "10x15": 1,
            "13x18": 2,
            "15x20": 3,
            "A4": 5
        };

        function calculatePhotoPrice() {
            const format = formatSelect.value;
            const quantity = parseInt(quantityInput.value) || 0;
            let unitPrice = formatPrices[format];

            // Reducere pentru formatul 10x15 cm la peste 100 bucăți
            if (format === '10x15' && quantity > 100) {
                unitPrice = 0.75;
            }

            const totalPrice = quantity * unitPrice;
            priceDisplay.innerText = `Cost Total: ${totalPrice.toFixed(2)} Lei`;
        }

        formatSelect.addEventListener('change', calculatePhotoPrice);
        quantityInput.addEventListener('input', calculatePhotoPrice);
        calculatePhotoPrice(); // Init calcul

        // Validarea formularului
        photoOrderForm.addEventListener('submit', function (event) {
            const photosInput = document.getElementById('photos');
            if (photosInput.files.length === 0) {
                alert('Te rugăm să încarci cel puțin o fotografie.');
                event.preventDefault();
            }
        });
    }

    // Calculul dinamic al prețului pentru pagina de printare documente
    const printOrderForm = document.getElementById('printOrderForm');
    if (printOrderForm) {
        const quantityInput = document.getElementById('quantity');
        const colorSelect = document.getElementById('color');
        const paperTypeSelect = document.getElementById('paperType');
        const bindingSelect = document.getElementById('binding');
        const priceDisplay = document.createElement('div');
        priceDisplay.className = "price-display mt-4 text-lg font-bold text-primary-color";
        printOrderForm.appendChild(priceDisplay);

        const basePrices = {
            "alb-negru": 0.1,
            "color": 0.5
        };

        const paperTypePrices = {
            "80g": 0,
            "90g": 0.1,
            "100g": 0.2
        };

        const bindingPrices = {
            "none": 0,
            "spiral": 2,
            "clema": 1
        };

        function calculatePrintPrice() {
            const quantity = parseInt(quantityInput.value) || 0;
            const colorPrice = basePrices[colorSelect.value];
            const paperPrice = paperTypePrices[paperTypeSelect.value];
            const bindingPrice = bindingPrices[bindingSelect.value];

            const totalPrice = quantity * (colorPrice + paperPrice) + bindingPrice;
            priceDisplay.innerText = `Cost Total: ${totalPrice.toFixed(2)} Lei`;
        }

        colorSelect.addEventListener('change', calculatePrintPrice);
        paperTypeSelect.addEventListener('change', calculatePrintPrice);
        bindingSelect.addEventListener('change', calculatePrintPrice);
        quantityInput.addEventListener('input', calculatePrintPrice);
        calculatePrintPrice(); // Init calcul

        // Validarea formularului
        printOrderForm.addEventListener('submit', function (event) {
            const filesInput = document.getElementById('files');
            if (filesInput.files.length === 0) {
                alert('Te rugăm să încarci cel puțin un document.');
                event.preventDefault();
            }
        });
    }
});
