
jQuery(function(){var a=jQuery;a.cookiesDirective({explicitConsent:!1,position:"bottom",duration:9999,limit:0,message:a("input[name=cookieData]").attr("data-cookie-text"),fontFamily:"Arial",fontColor:"#424a4d",fontSize:"13px",backgroundColor:"#eaeff1",backgroundOpacity:"80"});a(".cookieText").find("a").css({color:"#424a4d","text-decoration":"underline"});a("input[name=cookieData]").remove()});
