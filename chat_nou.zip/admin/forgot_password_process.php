<?php
include '../backend/config/db.php'; // Calea corectă către fișierul de configurare

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];

    try {
        $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $user, $pass);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        $stmt = $pdo->prepare("SELECT * FROM admins WHERE email = ?");
        $stmt->execute([$email]);
        $admin = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($admin) {
            // Generate a reset token
            $resetToken = bin2hex(random_bytes(16));

            // Update the admin record with the reset token
            $stmt = $pdo->prepare("UPDATE admins SET reset_token = ? WHERE email = ?");
            $stmt->execute([$resetToken, $email]);

            // Send reset email
            $resetLink = "https://centrucopierebm.ro/admin/reset_password.php?token=$resetToken";
            $subject = "Resetare parolă - Centru Copiere BM";
            $message = "Salut $admin[username],\n\nA fost făcută o cerere de resetare a parolei pentru contul tău.\n\nClick pe linkul de mai jos pentru a-ți reseta parola:\n$resetLink\n\nDacă nu ai solicitat această resetare, te rugăm să ignori acest mesaj.";
            $headers = "From: no-reply@centrucopierebm.ro";

            if (mail($email, $subject, $message, $headers)) {
                echo "Emailul de resetare a fost trimis cu succes!";
            } else {
                echo "Eroare la trimiterea emailului de resetare.";
            }
        } else {
            echo "Emailul nu a fost găsit în sistem.";
        }
    } catch (PDOException $e) {
        echo "Database error: " . $e->getMessage();
    }
} else {
    echo "Cerere invalidă.";
}
?>
