<?php
session_start();

// Verifică dacă utilizatorul este autentificat
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}

// Include configurarea bazei de date
include '../backend/config/db.php';

try {
    // Conectează-te la baza de date
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Fetch statistici
    $stmt = $pdo->query("SELECT COUNT(*) AS total_orders FROM orders");
    $totalOrders = $stmt->fetch(PDO::FETCH_ASSOC)['total_orders'];

    $stmt = $pdo->query("SELECT COUNT(*) AS new_orders FROM orders WHERE DATE(created_at) = CURDATE()");
    $newOrders = $stmt->fetch(PDO::FETCH_ASSOC)['new_orders'];

    $stmt = $pdo->query("SELECT COUNT(*) AS active_users FROM users WHERE status = 'active'");
    $activeUsers = $stmt->fetch(PDO::FETCH_ASSOC)['active_users'];
} catch (PDOException $e) {
    echo "Database error: " . $e->getMessage();
    exit();
}
?>

<!DOCTYPE html>
<html lang="ro">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panou de Administrare - Centru Copiere BM</title>
    <!-- Tailwind CSS -->
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <!-- Alpine.js -->
    <script src="https://cdn.jsdelivr.net/npm/alpinejs@3.4.2/dist/cdn.min.js" defer></script>
    <!-- FontAwesome pentru iconițe -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/js/all.min.js"></script>
    <style>
        .sidebar {
            background-color: #6b156b;
            color: #fff;
        }
    </style>
</head>

<body class="bg-gray-100 font-sans antialiased">
    <!-- Sidebar -->
    <div class="flex h-screen">
        <div class="sidebar w-64 py-8 px-4">
            <h2 class="text-center text-2xl font-bold mb-6">Admin Panel</h2>
            <nav>
                <a href="#dashboard" class="block py-2 px-4 rounded hover:bg-purple-700">Dashboard</a>
                <a href="#orders" class="block py-2 px-4 rounded hover:bg-purple-700">Comenzi</a>
                <a href="#users" class="block py-2 px-4 rounded hover:bg-purple-700">Utilizatori</a>
                <a href="#settings" class="block py-2 px-4 rounded hover:bg-purple-700">Setări</a>
                <a href="logout.php" class="block py-2 px-4 rounded hover:bg-purple-700">Logout</a>
            </nav>
        </div>

        <!-- Main Content -->
        <div class="flex-1 p-10 overflow-y-auto">
            <!-- Navbar -->
            <header class="flex justify-between items-center mb-6">
                <h1 class="text-3xl font-semibold">Panou de Administrare</h1>
                <div>
                    <a href="#" class="text-gray-600 hover:text-purple-700"><i class="fas fa-user-circle"></i> Profil</a>
                </div>
            </header>

            <!-- Dashboard -->
            <div id="dashboard" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
                <div class="bg-white p-6 rounded-lg shadow-lg">
                    <h5 class="text-lg font-semibold">Total Comenzi</h5>
                    <p class="mt-2 text-xl font-bold"><?php echo $totalOrders; ?></p>
                </div>
                <div class="bg-white p-6 rounded-lg shadow-lg">
                    <h5 class="text-lg font-semibold">Comenzi Noi</h5>
                    <p class="mt-2 text-xl font-bold"><?php echo $newOrders; ?></p>
                </div>
                <div class="bg-white p-6 rounded-lg shadow-lg">
                    <h5 class="text-lg font-semibold">Utilizatori Activi</h5>
                    <p class="mt-2 text-xl font-bold"><?php echo $activeUsers; ?></p>
                </div>
            </div>

            <!-- Comenzi Section -->
            <div id="orders" class="mb-8">
                <h2 class="text-2xl font-bold mb-4">Comenzi</h2>
                <div class="bg-white p-6 rounded-lg shadow-lg">
                    <div class="overflow-x-auto">
                        <table class="min-w-full table-auto">
                            <thead>
                                <tr class="bg-purple-700 text-white">
                                    <th class="py-2 px-4">ID Comandă</th>
                                    <th class="py-2 px-4">Nume Client</th>
                                    <th class="py-2 px-4">Telefon</th>
                                    <th class="py-2 px-4">Format</th>
                                    <th class="py-2 px-4">Data</th>
                                    <th class="py-2 px-4">Acțiuni</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                try {
                                    $stmt = $pdo->query("SELECT * FROM orders ORDER BY created_at DESC");
                                    while ($order = $stmt->fetch(PDO::FETCH_ASSOC)) {
                                        echo "<tr class='bg-gray-100'>
                                            <td class='py-2 px-4'>{$order['order_id']}</td>
                                            <td class='py-2 px-4'>{$order['customer_name']}</td>
                                            <td class='py-2 px-4'>{$order['customer_phone']}</td>
                                            <td class='py-2 px-4'>{$order['format']}</td>
                                            <td class='py-2 px-4'>{$order['created_at']}</td>
                                            <td class='py-2 px-4'>
                                                <button class='text-blue-500 hover:underline'>Vizualizează</button>
                                            </td>
                                        </tr>";
                                    }
                                } catch (PDOException $e) {
                                    echo "Error: " . $e->getMessage();
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Utilizatori Section -->
            <div id="users" class="mb-8">
                <h2 class="text-2xl font-bold mb-4">Utilizatori</h2>
                <div class="bg-white p-6 rounded-lg shadow-lg">
                    <div class="overflow-x-auto">
                        <table class="min-w-full table-auto">
                            <thead>
                                <tr class="bg-purple-700 text-white">
                                    <th class="py-2 px-4">ID Utilizator</th>
                                    <th class="py-2 px-4">Nume</th>
                                    <th class="py-2 px-4">Email</th>
                                    <th class="py-2 px-4">Data Înregistrării</th>
                                    <th class="py-2 px-4">Acțiuni</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                try {
                                    $stmt = $pdo->query("SELECT * FROM users ORDER BY created_at DESC");
                                    while ($user = $stmt->fetch(PDO::FETCH_ASSOC)) {
                                        echo "<tr class='bg-gray-100'>
                                            <td class='py-2 px-4'>{$user['id']}</td>
                                            <td class='py-2 px-4'>{$user['name']}</td>
                                            <td class='py-2 px-4'>{$user['email']}</td>
                                            <td class='py-2 px-4'>{$user['created_at']}</td>
                                            <td class='py-2 px-4'>
                                                <button class='text-blue-500 hover:underline'>Editează</button>
                                            </td>
                                        </tr>";
                                    }
                                } catch (PDOException $e) {
                                    echo "Error: " . $e->getMessage();
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Setări Section -->
            <div id="settings">
                <h2 class="text-2xl font-bold mb-4">Setări</h2>
                <div class="bg-white p-6 rounded-lg shadow-lg">
                    <form>
                        <div class="mb-4">
                            <label class="block text-gray-700 font-semibold mb-2" for="site-name">Nume Site</label>
                            <input class="w-full p-2 border rounded" type="text" id="site-name" placeholder="Centru Copiere BM">
                        </div>
                        <div class="mb-4">
                            <label class="block text-gray-700 font-semibold mb-2" for="admin-email">Email Admin</label>
                            <input class="w-full p-2 border rounded" type="email" id="admin-email" placeholder="admin@centrucopierebm.ro">
                        </div>
                        <button class="px-4 py-2 bg-purple-700 text-white rounded hover:bg-purple-800">Salvează</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="bg-purple-700 text-white text-center py-4">
        &copy; 2024 Centru Copiere BM. Toate drepturile rezervate.
    </footer>
</body>

</html>
