<?php
session_start();

$error = '';

// Verifică dacă formularul a fost trimis
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Exemplu de verificare a utilizatorului și parolei
    // Într-o aplicație reală, ar trebui să folosești o bază de date pentru verificare
    if ($username === 'admin' && password_verify($password, password_hash('parola_admin', PASSWORD_DEFAULT))) {
        $_SESSION['admin_logged_in'] = true;
        header('Location: /centrucopierebm.ro/admin/admin_dashboard.php');
        exit;
    } else {
        $error = 'Numele de utilizator sau parola sunt incorecte.';
    }
}
?>

<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Autentificare Admin</title>
    <!-- Tailwind CSS -->
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="flex items-center justify-center h-screen bg-gray-100">
    <div class="bg-white p-6 rounded-lg shadow-md w-full max-w-md">
        <h2 class="text-2xl font-bold mb-4 text-center">Autentificare Admin</h2>
        <?php if ($error): ?>
            <div class="bg-red-100 text-red-700 p-2 mb-4 rounded"><?php echo $error; ?></div>
        <?php endif; ?>
        <form action="" method="POST">
            <div class="mb-4">
                <label for="username" class="block text-lg font-semibold mb-2">Nume utilizator:</label>
                <input type="text" name="username" id="username" required class="w-full p-2 border border-gray-300 rounded">
            </div>
            <div class="mb-4">
                <label for="password" class="block text-lg font-semibold mb-2">Parolă:</label>
                <input type="password" name="password" id="password" required class="w-full p-2 border border-gray-300 rounded">
            </div>
            <button type="submit" class="mt-4 p-2 bg-purple-700 text-white rounded w-full hover:bg-purple-800 transition duration-200">Autentificare</button>
        </form>
        <a href="forgot_password.php" class="text-sm text-blue-500 hover:underline mt-4 block text-center">Ai uitat parola?</a>
    </div>
</body>
</html>
