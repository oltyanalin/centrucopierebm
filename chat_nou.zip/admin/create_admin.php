<?php
// Include database configuration
include '../backend/config/db.php'; // Calea corectă către fișierul de configurare

try {
    // Conectează-te la baza de date
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Datele administratorului - modifică aceste valori pentru a crea adminul dorit
    $username = 'admin'; // Numele de utilizator pentru administrator
    $password = 'admin_password'; // Parola administratorului
    $email = 'admin@centrucopierebm.ro'; // Adresa de email a administratorului

    // Verifică dacă utilizatorul deja există
    $checkStmt = $pdo->prepare("SELECT * FROM admins WHERE username = ? OR email = ?");
    $checkStmt->execute([$username, $email]);
    $existingAdmin = $checkStmt->fetch(PDO::FETCH_ASSOC);

    if ($existingAdmin) {
        echo "Administratorul deja există.";
    } else {
        // Hash the password for security
        $hashedPassword = password_hash($password, PASSWORD_BCRYPT);

        // Introducerea administratorului în baza de date
        $stmt = $pdo->prepare("INSERT INTO admins (username, password, email) VALUES (?, ?, ?)");
        $stmt->execute([$username, $hashedPassword, $email]);

        echo "Administratorul a fost creat cu succes!";
    }
} catch (PDOException $e) {
    echo "Database error: " . $e->getMessage();
}
?>
