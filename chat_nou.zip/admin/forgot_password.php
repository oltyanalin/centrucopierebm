<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recuperare Parolă</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100 flex justify-center items-center min-h-screen">
    <div class="bg-white p-8 rounded-lg shadow-lg max-w-sm w-full">
        <h1 class="text-2xl font-bold mb-4 text-center">Recuperare Parolă</h1>
        <form action="forgot_password_process.php" method="POST">
            <div class="mb-4">
                <label for="email" class="block text-lg font-semibold mb-2">Adresa de email</label>
                <input type="email" name="email" id="email" required class="w-full p-2 border border-gray-300 rounded">
            </div>
            <button type="submit" class="mt-6 p-3 bg-purple-700 text-white rounded shadow w-full hover:bg-purple-800 transition duration-200">Trimite Email</button>
        </form>
    </div>
</body>
</html>
