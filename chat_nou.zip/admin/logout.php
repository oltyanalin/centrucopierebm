<?php
session_start();
session_unset(); // Elimină toate variabilele de sesiune
session_destroy(); // Distruge sesiunea
header("Location: login.php"); // Redirecționează la pagina de autentificare
exit();
?>
