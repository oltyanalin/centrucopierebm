<!DOCTYPE html>
<html lang="ro">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Centru Copiere BM</title>
    <!-- Tailwind CSS -->
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <!-- FontAwesome Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css"
        integrity="sha384-k6RqeWeci5ZR/Lv4MR0sA0FfDOMRR3eVBvK0Wz0rj60x04/r4JOzxF3A7T9f4kwp" crossorigin="anonymous">
    <style>
        :root {
            --primary-color: #6B156B;
            --secondary-color: #B528B5;
            --whatsapp-color: #25D366;
            --email-color: #3B82F6;
        }

        body {
            background-color: #F4F4F4;
            font-family: 'Arial', sans-serif;
        }

        .fixed-top {
            position: fixed;
            top: 0;
            width: 100%;
            z-index: 50;
        }

        .header {
            background-color: #fff;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            padding: 16px;
        }

        .logo img {
            height: 50px; /* Ajustat pentru dimensiuni mai mici */
            width: auto;
        }

        .contact-info {
            display: flex;
            align-items: center;
            gap: 16px;
        }

        .contact-info a {
            display: flex;
            align-items: center;
            padding: 8px 12px;
            border-radius: 4px;
            transition: background-color 0.2s ease;
        }

        .whatsapp-button {
            background-color: var(--whatsapp-color);
            color: #fff;
        }

        .whatsapp-button:hover {
            background-color: #1DA851;
        }

        footer {
            background-color: var(--primary-color);
            color: #fff;
            padding: 24px;
            text-align: center;
        }

        footer a {
            color: #fff;
            text-decoration: underline;
        }

        @media (max-width: 768px) {
            .contact-info {
                justify-content: flex-end;
            }

            .contact-info span {
                display: none;
            }

            .header-icons {
                display: flex;
                align-items: center;
                gap: 16px;
            }

            .dropdown-menu-icon {
                color: var(--primary-color);
                cursor: pointer;
            }

            .container {
                padding-left: 1rem;
                padding-right: 1rem;
            }
        }
    </style>
</head>

<body class="flex flex-col min-h-screen">

    <!-- Header -->
    <header class="fixed-top header flex justify-between items-center px-8">
        <!-- Logo -->
        <div class="logo">
            <a href="/index.php">
                <img src="https://centrucopierebm.ro/assets/media/logo/logo-digital.png" alt="Logo Centru Copiere BM">
            </a>
        </div>

        <!-- Contact Info -->
        <div class="contact-info header-icons">
            <!-- WhatsApp Button -->
            <a href="https://wa.me/40746686157" target="_blank" class="whatsapp-button flex items-center">
                <i class="fab fa-whatsapp text-lg mr-2"></i> <!-- Folosim iconița FontAwesome -->
                <span class="hidden md:inline">WhatsApp</span>
            </a>
            <!-- Button for Price List -->
            <button id="priceListButton" class="bg-blue-500 text-white p-2 rounded-md shadow hover:bg-blue-600 transition">
                Lista de Prețuri
            </button>
            <!-- Dropdown Menu Icon -->
            <div class="dropdown-menu-icon md:hidden">
                <i class="fas fa-bars text-2xl"></i>
            </div>
        </div>
    </header>

    <!-- Spacer for Fixed Header -->
    <div class="mt-16"></div>

    <!-- Modal for Price List -->
    <div id="priceListModal" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center hidden">
        <div class="bg-white rounded-lg shadow-lg w-11/12 md:w-1/2 p-6 relative">
            <button id="closePriceList" class="absolute top-2 right-2 text-gray-600 hover:text-gray-900">
                <i class="fas fa-times text-xl"></i>
            </button>
            <h2 class="text-xl font-bold mb-4">Lista de Prețuri</h2>
            <table class="table-auto w-full text-left border-collapse">
                <thead>
                    <tr>
                        <th class="px-4 py-2 bg-gray-100 border-b">Format</th>
                        <th class="px-4 py-2 bg-gray-100 border-b">Preț (lei)</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td class="px-4 py-2 border-b">10x15 cm</td>
                        <td class="px-4 py-2 border-b">1</td>
                    </tr>
                    <tr>
                        <td class="px-4 py-2 border-b">13x18 cm</td>
                        <td class="px-4 py-2 border-b">2</td>
                    </tr>
                    <tr>
                        <td class="px-4 py-2 border-b">15x20 cm</td>
                        <td class="px-4 py-2 border-b">3</td>
                    </tr>
                    <tr>
                        <td class="px-4 py-2 border-b">A4</td>
                        <td class="px-4 py-2 border-b">5</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>

    <!-- JavaScript pentru deschiderea/închiderea modalului -->
    <script>
        // Deschidere modal pentru lista de prețuri
        document.getElementById('priceListButton').addEventListener('click', function () {
            document.getElementById('priceListModal').classList.remove('hidden');
        });

        // Închidere modal pentru lista de prețuri
        document.getElementById('closePriceList').addEventListener('click', function () {
            document.getElementById('priceListModal').classList.add('hidden');
        });

        // Închidere modal la click în afara acestuia
        document.getElementById('priceListModal').addEventListener('click', function (e) {
            if (e.target === this) {
                this.classList.add('hidden');
            }
        });
    </script>
