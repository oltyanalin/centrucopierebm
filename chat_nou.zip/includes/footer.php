    <!-- Footer -->
    <footer>
        <div class="container mx-auto px-4">
            <p>&copy; 2024 Centru Copiere BM. Toate drepturile rezervate.</p>
            <p><a href="#">Politica de Confidențialitate</a> | <a href="#">Termeni și Condiții</a></p>
            <p>Urmărește-ne pe <a href="#">Facebook</a>, <a href="#">Instagram</a>, <a href="#">LinkedIn</a></p>
        </div>
    </footer>

</body>

</html>
